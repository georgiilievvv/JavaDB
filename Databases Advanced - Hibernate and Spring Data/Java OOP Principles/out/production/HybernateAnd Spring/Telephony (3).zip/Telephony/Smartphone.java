package Telephony;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Smartphone implements NumberValidation,SiteValidation{

    private List<String> phoneNum;
    private List<String> sites;

    public Smartphone(List<String> phoneNum, List<String> sites) {
        this.phoneNum = phoneNum;
        this.sites = sites;
    }

    @Override
    public void call() {
        for (String number: phoneNum ) {

            Pattern p = Pattern.compile("\\d+");
            Matcher m = p.matcher(number);
            boolean b = m.matches();

            System.out.println(b ? "Calling... " + number : "Invalid number!");
        }
    }

    @Override
    public void checkSite() {
        for (String site: sites ) {

            Pattern p = Pattern.compile("\\d+");
            Matcher m = p.matcher(site);
            boolean b = m.matches();

            System.out.println(b ? "Invalid URL!" : "Browsing: " + site + '!');
        }
    }
}
