package Telephony;

public interface SiteValidation {
     void checkSite();
}
