package Telephony;

public interface NumberValidation {
    void call();
}
